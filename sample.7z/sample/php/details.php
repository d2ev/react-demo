<?php

require_once "storage.php";

$movieTitle = $_GET['movie'];
$movieCategory = NULL;
foreach ($movies as $category => $categoryMovies) {
    if (in_array($movieTitle, $categoryMovies)) {
        $movieCategory = $category;
        break;
    }
}

$similarMovies = array_diff($movies[$movieCategory], [$movieTitle]);
$output = [];
foreach ($similarMovies as $similarMovie) {
    $output[$similarMovie] = [
        "title" => $similarMovie,
        "image" => $movieDetails[$similarMovie]["image"]
    ];
}

echo json_encode([
    "movie" => $movieDetails[$movieTitle],
    "similar" => $output
]);