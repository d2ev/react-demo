<?php
require_once "storage.php";
$output = [];
foreach ($movies as $category => $categoryMovies) {
    foreach ($categoryMovies as $movie) {
        $output[$category][$movie] = [
            "title" => $movie,
            "image" => $movieDetails[$movie]["image"]
        ];
    }
}
echo json_encode($output);
