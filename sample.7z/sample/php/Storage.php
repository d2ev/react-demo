<?php

$movies = [
    "comedy" => [
        "Pink Panther",
        "Johny English",
        "Borat",
        "Dumb and Dumber",
        "Ace Ventura"
    ],
    "tragedy" => [
        "Romeo and Juliet",
        "Titanic",
        "The Notebook",
        "A Walk to Remember",
        "Love Story"
    ],
    "action" => [
        "Die Hard",
        "Terminator",
        "Rambo",
        "The Expendables",
        "Robocop"
    ]
];

$movieDetails = [
    "Pink Panther" => [
        "rating" => "PG",
        "year" => "2006",
        "stars" => "Steve Martin, Kevin Kline",
        "image" => "images/pink_panther.jpg",
        "description" => "A detective must solve the"
    ],
    "Johny English" => [
        "rating" => "PG",
        "year" => "2003",
        "stars" => "Rowan Atkinson, John Malkovich",
        "image" => "images/johny_english.jpg",
        "description" => "The bumbling British"
    ],
    "Borat" => [
        "rating" => "R",
        "year" => "2006",
        "stars" => "Sacha Baron Cohen",
        "image" => "images/borat.jpg",
        "description" => "An eccentric journalist"
    ],
    "Dumb and Dumber" => [
        "rating" => "PG-13",
        "year" => "1994",
        "stars" => "Jim Carrey, Jeff Daniels",
        "image" => "images/dumb_and_dumber.jpg",
        "description" => "The cross-country adventures"
    ],
    "Ace Ventura" => [
        "rating" => "PG-13",
        "year" => "1994",
        "stars" => "Jim Carrey, Courteney Cox",
        "image" => "images/ace_ventura.jpg",
        "description" => "A goofy detective"
    ],
    "Romeo and Juliet" => [
        "rating" => "PG",
        "year" => "1968",
        "stars" => "Leonard Whiting, Olivia Hussey",
        "image" => "images/romeo_and_juliet.jpg",
        "description" => "Shakespeare's classic tale"
    ],
    "Titanic" => [
        "rating" => "PG-13",
        "year" => "1997",
        "stars" => "Leonardo DiCaprio, Kate Winslet",
        "image" => "images/titanic.jpg",
        "description" => "A love story doomed by the"
    ],
    "The Notebook" => [
        "rating" => "PG-13",
        "year" => "2004",
        "stars" => "Ryan Gosling, Rachel McAdams",
        "image" => "images/the_notebook.jpg",
        "description" => "A poor yet passionate"
    ],
    "A Walk to Remember" => [
        "rating" => "PG",
        "year" => "2002",
        "stars" => "Mandy Moore, Shane West",
        "image" => "images/a_walk_to_remember.jpg",
        "description" => "A story of two North"
    ],
    "Love Story" => [
        "rating" => "PG",
        "year" => "1970",
        "stars" => "Ali MacGraw, Ryan O'Neal",
        "image" => "images/love_story.jpg",
        "description" => "A tale of love"
    ],
    "Die Hard" => [
        "rating" => "R",
        "year" => "1988",
        "stars" => "Bruce Willis, Alan Rickman",
        "image" => "images/die_hard.jpg",
        "description" => "New York City policeman"
    ],
    "Terminator" => [
        "rating" => "R",
        "year" => "1984",
        "stars" => "Arnold Schwarzenegger, Linda Hamilton",
        "image" => "images/terminator.jpg",
        "description" => "A cyborg from a post-apocalyptic"
    ],
    "Rambo" => [
        "rating" => "R",
        "year" => "2008",
        "stars" => "Sylvester Stallone",
        "image" => "images/rambo.jpg",
        "description" => "A war veteran uses his"
    ],
    "The Expendables" => [
        "rating" => "R",
        "year" => "2010",
        "stars" => "Sylvester Stallone, Jason Statham",
        "image" => "images/the_expendables.jpg",
        "description" => "A group of elite mercenaries"
    ],
    "Robocop" => [
        "rating" => "R",
        "year" => "1987",
        "stars" => "Peter Weller, Nancy Allen",
        "image" => "images/robocop.jpg",
        "description" => "In a dystopic and crime-ridden"
    ]
];