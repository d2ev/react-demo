// Load jQuery using the $ alias
function loadMoviesList() {
    $.ajax({url: "php/list.php", success: function(result){
        let list = JSON.parse(result);
        Object.keys(list).forEach(function(category) {
            let identifier = `category-${category}`;
            let cardGroup = `<div class="category-wrapper m-3"><h3 class="text-capitalize">${category}</h3><div id="${identifier}" class="card-group"></div></div>`;
            $('#movies-list-page .container').append(cardGroup);
            listComponent('#' + identifier, list[category])
        });
    }});
}

function loadMovieDetails(){
    let url = new URL(window.location.href);
    let movie = url.searchParams.get("movie");
    $.ajax({url: "php/details.php?movie=" + movie, success: function(result){
            let data = JSON.parse(result);
            $('#breadcrumb-title').html(movie);
            $('#movies-details-page .container .section-details').append(detailsComponent(data.movie, movie));
            listComponent('#movies-details-page .container .section-similar', data.similar)
        }});
}

let listComponent = function (identifier, category) {
    for(let movie in category) {
        let card = cardComponent(category[movie]);
        $(identifier).append(card);
    }
};
let cardComponent = function (movie) {
    return `<div class="card">
        <a href="/sample/details.html?movie=${movie.title}" title="${movie.title}">
        <img src="${movie.image}" class="card-img p-3" alt="${movie.title}">
        </a> 
    </div>`;
}

let detailsComponent = function (movie, title) {
    return `<div class="card mb-3">
              <div class="row g-0">
                <div class="col-md-4">
                  <img src="${movie.image}" class="card-img p-3" alt="${title}">
                </div>
                <div class="col-md-8">
                  <div class="card-body">
                    <h5 class="card-title">${title}</h5>
                    <p class="card-text"><label class="pe-1">Rating: </label>${movie.rating}</p>
                    <p class="card-text"><label class="pe-1">Year: </label>${movie.year}</p>
                    <p class="card-text"><label class="pe-1">Starts: </label>${movie.stars}</p>
                    <p class="card-text"><small class="text-muted">${movie.description}</small></p>
                  </div>
                </div>
              </div>
            </div>`;
};